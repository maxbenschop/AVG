<!DOCTYPE html>
<html>
  <head>
    <title>Bedankt</title>
    <link href="css/style.css" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <h1>Bedankt voor uw inschrijving</h1>
    <p>Uw gegevens zijn verwerkt!</p>
  </body>
</html>
