<?php
class database
{
  var $dbh;

  // verbinden met database
  function connect()
  {
    $hostname = "localhost";
    $database = "AVG_process";
    $username = "AVG_process";
    $password = "Vk@m8263g";

    try {
      $this->dbh = new PDO("mysql:host=" . $hostname . ";dbname=" . $database . ";", $username, $password);
    } catch (PDOException $e) {
      echo "Error: " . $e->getMessage();
    }
  }

  // haal alle gegevens van 1 klant op
  function getKlant($id)
  {
    $statement = $this->dbh->prepare("SELECT * FROM klanten WHERE id = :id");
    $result = $statement->execute(array(":id" => $id));
    $klant = $statement->fetch(PDO::FETCH_ASSOC);
    return $klant;
  }


  // functie om de tabel leeg te maken
  function clearTable()
  {
    try {
      $sql = $this->dbh->prepare("TRUNCATE TABLE klanten");
      if ($result = $sql->execute()) {
        return true;
      } else {
        return false;
      }
    } catch (PDOException $e) {
      echo "Error: " . $e->getMessage();
    }
  }


  // haal overzicht van alle klanten op
  function getKlanten()
  {
    $result = $this->dbh->query("SELECT id, voornaam, tussenvoegsel, achternaam FROM klanten ORDER BY achternaam");
    $result = $result->fetchAll(PDO::FETCH_ASSOC);
    return $result;
  }

  // voeg nieuwe klant toe
  function insertKlant($voornaam, $tussenvoegsel, $achternaam, $geboortedatum)
  {
    try {
      $sql = $this->dbh->prepare("INSERT INTO klanten (`voornaam`, `tussenvoegsel`, `achternaam`, `geboortedatum`) VALUES (:voornaam, :tussenvoegsel, :achternaam, :geboortedatum)");
      $sql->bindParam(':voornaam', $voornaam, PDO::PARAM_STR);
      $sql->bindParam(':tussenvoegsel', $tussenvoegsel, PDO::PARAM_STR);
      $sql->bindParam(':achternaam', $achternaam, PDO::PARAM_STR);
      $sql->bindParam(':geboortedatum', $geboortedatum, PDO::PARAM_STR);
      if ($result = $sql->execute()) {
        return $this->dbh->lastInsertId();
      } else {
        return false;
      }
    } catch (PDOException $e) {
      echo "Error: " . $e->getMessage();
    }
  }

}



$db = new database();
$db->connect();
// $db->clearTable();
?>